// SPECTER PROTOCOL - Multiplayer Server
// Usage: npm install ws && node server.js
// Then open: http://localhost:8080

var http = require('http');
var fs = require('fs');
var path = require('path');
var WebSocket = require('ws');

var PORT = process.env.PORT || 8080;
var MAX_PLAYERS = 10;
var rooms = {};

function genCode() {
  var c = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  var r = '';
  for (var i = 0; i < 6; i++) r += c[Math.floor(Math.random() * c.length)];
  return r;
}

function sanitize(s) {
  if (!s) return '';
  return String(s).replace(/[<>&"']/g, '').trim().slice(0, 48);
}

function pData(p) {
  return { id: p.pid, username: p.username, pos: p.pos, yaw: p.yaw, pitch: p.pitch,
    health: p.health, alive: p.alive, kills: p.kills, deaths: p.deaths,
    opType: p.opType, team: p.team, ready: p.ready, weaponIdx: p.weaponIdx };
}

function send(ws, msg) {
  try { if (ws.readyState === 1) ws.send(JSON.stringify(msg)); } catch(e){}
}

function bcast(code, msg, excludeId) {
  if (!rooms[code]) return;
  var j = JSON.stringify(msg);
  rooms[code].players.forEach(function(p) {
    try { if (p.pid !== excludeId && p.readyState === 1) p.send(j); } catch(e) {}
  });
}

function scores(code) {
  if (!rooms[code]) return [];
  return rooms[code].players.map(function(p) {
    return { id: p.pid, username: p.username, kills: p.kills, deaths: p.deaths, team: p.team, alive: p.alive };
  });
}

function lobbyUpdate(code) {
  if (!rooms[code]) return;
  bcast(code, { type: 'lobbyUpdate', players: rooms[code].players.map(pData) }, null);
}

var server = http.createServer(function(req, res) {
  var url = req.url.split('?')[0];
  if (url === '/' || url === '/index.html') {
    var fp = path.join(__dirname, 'specter-multiplayer.html');
    fs.readFile(fp, function(err, data) {
      if (err) { res.writeHead(404); res.end('Place specter-multiplayer.html in same directory as server.js'); return; }
      res.writeHead(200, {'Content-Type':'text/html;charset=utf-8','Cache-Control':'no-cache'});
      res.end(data);
    });
  } else { res.writeHead(404); res.end(); }
});

var wss = new WebSocket.Server({ server: server });

wss.on('connection', function(ws) {
  ws.pid = Math.random().toString(36).slice(2,10);
  ws.username = 'Operator'; ws.roomCode = null;
  ws.pos = {x:0,y:1.7,z:25}; ws.yaw = 0; ws.pitch = 0;
  ws.health = 100; ws.alive = true;
  ws.kills = 0; ws.deaths = 0;
  ws.opType = 'ghost'; ws.team = 'blue';
  ws.weaponIdx = 0; ws.ready = false;

  ws.on('message', function(raw) {
    try { handleMsg(ws, JSON.parse(raw.toString())); } catch(e) {}
  });

  ws.on('close', function() {
    if (!ws.roomCode || !rooms[ws.roomCode]) return;
    var room = rooms[ws.roomCode];
    room.players = room.players.filter(function(p){ return p.pid !== ws.pid; });
    bcast(ws.roomCode, {type:'playerLeft', id:ws.pid, username:ws.username});
    bcast(ws.roomCode, {type:'chatMsg', id:'sys', username:'SERVER', message:ws.username+' disconnected', sys:true});
    if (room.players.length === 0) { delete rooms[ws.roomCode]; console.log('[SPECTER] Room '+ws.roomCode+' closed'); }
    else lobbyUpdate(ws.roomCode);
  });

  ws.on('error', function(){});
});

function handleMsg(ws, msg) {
  switch(msg.type) {
    case 'createRoom': {
      var code = genCode(); while(rooms[code]) code = genCode();
      ws.username = sanitize(msg.username) || 'Operator';
      ws.opType = msg.opType || 'ghost';
      ws.team = 'blue'; ws.roomCode = code; ws.ready = false;
      rooms[code] = { code:code, players:[ws], host:ws.pid, gameStarted:false, created:Date.now() };
      send(ws, {type:'welcome', id:ws.pid, roomCode:code, isHost:true, players:[]});
      console.log('[SPECTER] Room '+code+' created by '+ws.username);
      break;
    }
    case 'joinRoom': {
      var code = (msg.roomCode||'').toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,6);
      if (!rooms[code]) { send(ws, {type:'error', msg:'Room '+code+' not found'}); return; }
      var room = rooms[code];
      if (room.players.length >= MAX_PLAYERS) { send(ws, {type:'error', msg:'Room is full ('+MAX_PLAYERS+'/'+MAX_PLAYERS+')'}); return; }
      ws.username = sanitize(msg.username) || 'Operator';
      ws.opType = msg.opType || 'ghost';
      ws.team = room.players.filter(function(p){return p.team==='blue';}).length <= room.players.filter(function(p){return p.team==='red';}).length ? 'blue':'red';
      ws.roomCode = code; ws.ready = false;
      var existing = room.players.map(pData);
      room.players.push(ws);
      send(ws, {type:'welcome', id:ws.pid, roomCode:code, isHost:false, players:existing});
      bcast(code, {type:'playerJoined', player:pData(ws)}, ws.pid);
      bcast(code, {type:'chatMsg', id:'sys', username:'SERVER', message:ws.username+' joined', sys:true});
      lobbyUpdate(code);
      break;
    }
    case 'move': {
      if (!ws.roomCode) return;
      ws.pos = msg.pos||ws.pos; ws.yaw = msg.yaw||0; ws.pitch = msg.pitch||0;
      ws.weaponIdx = msg.wi||0;
      bcast(ws.roomCode, {type:'playerUpdate', id:ws.pid, pos:ws.pos, yaw:ws.yaw, pitch:ws.pitch, wi:ws.weaponIdx, mv:msg.mv, sh:msg.sh}, ws.pid);
      break;
    }
    case 'shoot': {
      if (!ws.roomCode) return;
      bcast(ws.roomCode, {type:'playerFired', id:ws.pid, from:msg.from, dir:msg.dir, wi:ws.weaponIdx}, ws.pid);
      break;
    }
    case 'hit': {
      if (!ws.roomCode||!rooms[ws.roomCode]) return;
      var room = rooms[ws.roomCode];
      var target = null;
      for (var i=0;i<room.players.length;i++) { if(room.players[i].pid===msg.tid){target=room.players[i];break;} }
      if (!target||!target.alive) return;
      // Distance sanity check
      var dx=ws.pos.x-target.pos.x, dz=ws.pos.z-target.pos.z;
      if (dx*dx+dz*dz > 6400) return;
      var dmg = Math.min(100, Math.max(1, Math.floor(msg.dmg)||30));
      target.health -= dmg;
      if (target.health <= 0) {
        target.health = 0; target.alive = false; target.deaths++;
        ws.kills++;
        bcast(ws.roomCode, {type:'playerDied', id:target.pid, killerId:ws.pid, kn:ws.username, vn:target.username, w:msg.w||'XR-4'});
        var tc=ws.roomCode, tid2=target.pid;
        setTimeout(function(){
          if (!rooms[tc]) return;
          var t2=null; for(var j=0;j<rooms[tc].players.length;j++){if(rooms[tc].players[j].pid===tid2){t2=rooms[tc].players[j];break;}}
          if (!t2) return;
          t2.health=100; t2.alive=true;
          var sp = t2.team==='blue'?{x:(Math.random()-.5)*8,y:1.7,z:25}:{x:(Math.random()-.5)*8,y:1.7,z:-25};
          t2.pos=sp;
          bcast(tc, {type:'playerRespawned', id:tid2, pos:sp});
        }, 3000);
      } else {
        send(target, {type:'tookDamage', dmg:dmg, fn:ws.username, fid:ws.pid});
        bcast(ws.roomCode, {type:'playerHurt', id:target.pid, hp:target.health}, null);
      }
      bcast(ws.roomCode, {type:'scoreUpdate', scores:scores(ws.roomCode)}, null);
      break;
    }
    case 'chat': {
      if (!ws.roomCode) return;
      var m = sanitize(msg.msg||msg.message||'').slice(0,200);
      if (!m) return;
      bcast(ws.roomCode, {type:'chatMsg', id:ws.pid, username:ws.username, message:m});
      break;
    }
    case 'ready': {
      ws.ready = !!msg.ready;
      if (ws.roomCode) bcast(ws.roomCode, {type:'playerReady', id:ws.pid, ready:ws.ready}, null);
      break;
    }
    case 'startGame': {
      if (!ws.roomCode||!rooms[ws.roomCode]) return;
      if (rooms[ws.roomCode].host !== ws.pid) return;
      rooms[ws.roomCode].gameStarted = true;
      bcast(ws.roomCode, {type:'gameStart'}, null);
      console.log('[SPECTER] Game started in room '+ws.roomCode);
      break;
    }
    case 'respawnAt': {
      ws.pos = msg.pos||ws.pos; ws.health=100; ws.alive=true;
      break;
    }
  }
}

server.listen(PORT, function() {
  console.log('');
  console.log('  ╔═══════════════════════════════════╗');
  console.log('  ║   SPECTER PROTOCOL - SERVER       ║');
  console.log('  ║   http://localhost:' + PORT + '           ║');
  console.log('  ║   Share your IP with friends      ║');
  console.log('  ╚═══════════════════════════════════╝');
  console.log('');
});
